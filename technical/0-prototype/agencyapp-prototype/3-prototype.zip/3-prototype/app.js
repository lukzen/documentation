// ========== BOOKING STATE ==========

const bookingState = {
  hotel: 'Gran Muthu Habana',
  hotelStars: '★★★★★',
  room: 'Standard Room',
  mealPlan: 'Bed & Breakfast',
  price: '194.40',
  cancellationPolicy: 'Free cancellation until Mar 25',
  checkin: '2026-03-25',
  checkout: '2026-03-27',
  guestFirstName: 'Testing',
  guestLastName: 'Guest',
  guestEmail: 'mayankjariwala1994@gmail.com',
  bookingRef: null,
  confirmationDate: null,
  isCancelled: false
};

// ========== HELPERS ==========

function formatDate(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
}

function formatDateShort(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function nightsBetween(checkin, checkout) {
  const d1 = new Date(checkin);
  const d2 = new Date(checkout);
  return Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24)));
}

function generateBookingRef() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let ref = 'EC';
  for (let i = 0; i < 12; i++) ref += chars[Math.floor(Math.random() * chars.length)];
  return ref;
}

function nowFormatted() {
  return new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// ========== TIME-AWARE GREETING ==========

(function setGreeting() {
  const el = document.getElementById('nav-greeting');
  if (!el) return;
  const hour = new Date().getHours();
  let greeting = 'Good evening';
  if (hour >= 5 && hour < 12) greeting = 'Good morning';
  else if (hour >= 12 && hour < 17) greeting = 'Good afternoon';
  el.textContent = greeting + ', Travel Agent';
})();

// ========== SCREEN NAVIGATION ==========

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + id).classList.add('active');
  document.querySelectorAll('.proto-tab').forEach(t => t.classList.remove('active'));
  const tab = document.querySelector(`[data-screen="${id}"]`);
  if (tab) tab.classList.add('active');
  window.scrollTo(0, 0);
  // Auto-render document previews when navigating to them
  if (id === 'voucher') renderVoucherPreview();
  if (id === 'invoice') renderInvoicePreview();
}

// Prototype toolbar tab clicks
document.querySelectorAll('.proto-tab').forEach(tab => {
  tab.addEventListener('click', () => showScreen(tab.dataset.screen));
});

// Toggle change callouts
const changesToggle = document.getElementById('changesToggle');
let changesVisible = false;

changesToggle.addEventListener('click', () => {
  changesVisible = !changesVisible;
  document.body.classList.toggle('show-changes', changesVisible);
  changesToggle.textContent = changesVisible ? 'Hide Changes' : 'Show Changes';
  changesToggle.classList.toggle('active', changesVisible);
});

// Close occupancy dropdown on outside click
document.addEventListener('click', (e) => {
  const dd = document.getElementById('occupancy-dropdown');
  if (dd && !e.target.closest('.occupancy-trigger') && !e.target.closest('.occupancy-dropdown')) {
    dd.classList.remove('show');
  }
});

// Keyboard navigation
document.addEventListener('keydown', (e) => {
  if (document.querySelector('.modal-overlay.open') || e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
  const screens = ['home', 'results', 'hotel', 'guest', 'payment', 'confirmation', 'bookings', 'booking-detail'];
  const current = screens.findIndex(s => document.getElementById('screen-' + s).classList.contains('active'));
  if (e.key === 'ArrowRight' && current < screens.length - 1) showScreen(screens[current + 1]);
  if (e.key === 'ArrowLeft' && current > 0) showScreen(screens[current - 1]);
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
    document.body.classList.remove('modal-open');
  }
});

// ========== SEARCH WITH LOADING ==========

function performSearch() {
  const overlay = document.getElementById('search-loading');
  overlay.classList.add('show');
  setTimeout(() => {
    overlay.classList.remove('show');
    showScreen('results');
  }, 1200);
}

// ========== MODAL LOGIC ==========

function openModal(id) {
  const modal = document.getElementById(id);
  modal.classList.add('open');
  document.body.classList.add('modal-open');

  if (id === 'cancel-modal') {
    document.getElementById('cancel-step-1').classList.add('active');
    document.getElementById('cancel-step-2').classList.remove('active');
    const checkbox = document.getElementById('cancel-confirm-check');
    if (checkbox) checkbox.checked = false;
    const btn = document.getElementById('confirm-cancel-btn');
    if (btn) btn.disabled = true;
    const reason = document.getElementById('cancel-reason');
    if (reason) reason.value = '';
  }
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.classList.remove('modal-open');
}

function closeModalOnOverlay(e) {
  if (e.target === e.currentTarget) {
    e.target.classList.remove('open');
    document.body.classList.remove('modal-open');
  }
}

// ========== CANCEL FLOW STEPS ==========

function goToCancelStep2() {
  document.getElementById('cancel-step-1').classList.remove('active');
  document.getElementById('cancel-step-2').classList.add('active');
}

function goToCancelStep1() {
  document.getElementById('cancel-step-2').classList.remove('active');
  document.getElementById('cancel-step-1').classList.add('active');
}

function toggleConfirmCancel() {
  const checkbox = document.getElementById('cancel-confirm-check');
  const reason = document.getElementById('cancel-reason');
  const btn = document.getElementById('confirm-cancel-btn');
  btn.disabled = !(checkbox.checked && reason.value.trim().length > 0);
}

document.addEventListener('input', (e) => {
  if (e.target.id === 'cancel-reason') toggleConfirmCancel();
});

// ========== STEPPER LOGIC ==========

document.querySelectorAll('.occ-stepper, .modal-stepper').forEach(stepper => {
  const btns = stepper.querySelectorAll('.occ-step-btn');
  const valEl = stepper.querySelector('span, .stepper-input');
  if (btns.length === 2 && valEl) {
    btns[0].addEventListener('click', () => {
      const v = parseInt(valEl.value || valEl.textContent);
      if (v > 0) { valEl.value !== undefined ? valEl.value = v - 1 : valEl.textContent = v - 1; }
    });
    btns[1].addEventListener('click', () => {
      const v = parseInt(valEl.value || valEl.textContent);
      if (v < 10) { valEl.value !== undefined ? valEl.value = v + 1 : valEl.textContent = v + 1; }
    });
  }
});

// ========== BOOKING FLOW ==========

function bookRoom(room, mealPlan, price, cancellationPolicy) {
  bookingState.room = room;
  bookingState.mealPlan = mealPlan;
  bookingState.price = price;
  bookingState.cancellationPolicy = cancellationPolicy;
  bookingState.checkin = document.getElementById('home-checkin').value || '2026-03-25';
  bookingState.checkout = document.getElementById('home-checkout').value || '2026-03-27';
  showScreen('guest');
}

function confirmBooking() {
  // Capture guest info from the form
  const guestScreen = document.getElementById('screen-guest');
  const inputs = guestScreen.querySelectorAll('.form-input');
  if (inputs[0]) bookingState.guestFirstName = inputs[0].value;
  if (inputs[1]) bookingState.guestLastName = inputs[1].value;
  if (inputs[2]) bookingState.guestEmail = inputs[2].value;

  // Generate booking reference and timestamp
  bookingState.bookingRef = generateBookingRef();
  bookingState.confirmationDate = nowFormatted();
  bookingState.isCancelled = false;

  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);
  const guestName = bookingState.guestFirstName + ' ' + bookingState.guestLastName;

  // Populate confirmation screen
  document.getElementById('conf-ref').textContent = bookingState.bookingRef;
  document.getElementById('conf-date').textContent = bookingState.confirmationDate;
  document.getElementById('conf-hotel').textContent = bookingState.hotel + ' ' + bookingState.hotelStars;
  document.getElementById('conf-room').textContent = bookingState.room;
  document.getElementById('conf-meal').textContent = bookingState.mealPlan;
  document.getElementById('conf-checkin').textContent = formatDate(bookingState.checkin);
  document.getElementById('conf-checkout').textContent = formatDate(bookingState.checkout);
  document.getElementById('conf-duration').textContent = nights + ' Night' + (nights !== 1 ? 's' : '');
  document.getElementById('conf-guest-name').textContent = guestName;
  document.getElementById('conf-guest-email').textContent = bookingState.guestEmail;
  document.getElementById('conf-price').textContent = 'USD ' + bookingState.price;

  // Also update booking detail and list to match
  updateBookingDetailFromState();
  updateBookingListFromState();

  showScreen('confirmation');

  // Trigger celebratory confetti
  spawnConfetti();
}

// ========== MODIFICATION ==========

function confirmModification() {
  const checkin = document.getElementById('modify-checkin').value;
  const checkout = document.getElementById('modify-checkout').value;

  // Get first room's selection for the booking state (primary room)
  const selects = document.querySelectorAll('#modify-rooms-container .modify-room-select');
  const firstSelect = selects[0];
  const selectedText = firstSelect.options[firstSelect.selectedIndex].text;

  const match = selectedText.match(/^(.+?)\s*—\s*(.+?)\s*\(USD\s*([\d,.]+)\)$/);
  if (match) {
    bookingState.room = match[1].trim();
    bookingState.mealPlan = match[2].trim();
  }

  // Calculate total price across all rooms
  bookingState.price = calculateModifyTotal().toFixed(2);
  bookingState.checkin = checkin;
  bookingState.checkout = checkout;

  // Update booking detail screen
  updateBookingDetailFromState();

  // Update booking list card
  updateBookingListFromState();

  // Add "Modified" timeline entry
  addTimelineEntry('amber', 'Modified: ' + nowFormatted());

  closeModal('modify-modal');
  showToast('success', 'Booking Modified', 'Your booking has been successfully updated with ' + selects.length + ' room' + (selects.length > 1 ? 's' : '') + '.');
}

// ========== MODIFY MODAL — ROOM MANAGEMENT ==========

function getModifyRoomCount() {
  return document.querySelectorAll('#modify-rooms-container .modal-room-card').length;
}

function updateModifyRoomHeaders() {
  const title = document.getElementById('modify-rooms-title');
  const note = document.getElementById('modify-rooms-note');
  const count = getModifyRoomCount();
  title.textContent = 'Rooms (' + count + ')';

  if (count === 1) {
    note.textContent = 'No change in room count';
    note.style.color = '';
  } else {
    note.textContent = '+' + (count - 1) + ' room' + (count - 1 > 1 ? 's' : '') + ' added';
    note.style.color = '#059669';
  }
}

function calculateModifyTotal() {
  let total = 0;
  document.querySelectorAll('#modify-rooms-container .modify-room-select').forEach(sel => {
    total += parseFloat(sel.value) || 0;
  });
  return total;
}

function updateModifyTotal() {
  const el = document.getElementById('modify-total-amount');
  if (el) el.textContent = 'USD ' + calculateModifyTotal().toFixed(2);
}

function addModifyRoom() {
  const container = document.getElementById('modify-rooms-container');
  const count = getModifyRoomCount() + 1;

  if (count > 5) {
    showToast('info', 'Room Limit', 'Maximum 5 rooms per booking.');
    return;
  }

  const card = document.createElement('div');
  card.className = 'modal-room-card';
  card.dataset.roomIndex = count;
  card.innerHTML =
    '<div class="modal-room-card-header">' +
      '<h4>Room ' + count + '</h4>' +
      '<button class="btn-remove-room" type="button" onclick="removeModifyRoom(this)">' +
        '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg>' +
        'Remove' +
      '</button>' +
    '</div>' +
    '<div class="modal-form-row">' +
      '<div class="modal-form-group" style="flex:2">' +
        '<label>Select Available Room</label>' +
        '<select class="form-input modify-room-select" onchange="updateModifyTotal()">' +
          '<option value="194.40">Standard Room — Bed &amp; Breakfast (USD 194.40)</option>' +
          '<option value="294.40">Standard Room — Half Board (USD 294.40)</option>' +
          '<option value="394.40">Standard Room — All Inclusive (USD 394.40)</option>' +
          '<option value="284.00">Superior Room Ocean View — Bed &amp; Breakfast (USD 284.00)</option>' +
        '</select>' +
      '</div>' +
    '</div>' +
    '<div class="modal-form-row">' +
      '<div class="modal-form-group">' +
        '<label>Adults</label>' +
        '<div class="modal-stepper">' +
          '<button class="occ-step-btn" type="button">−</button>' +
          '<input type="number" value="2" class="stepper-input" readonly>' +
          '<button class="occ-step-btn" type="button">+</button>' +
        '</div>' +
      '</div>' +
      '<div class="modal-form-group">' +
        '<label>Children</label>' +
        '<div class="modal-stepper">' +
          '<button class="occ-step-btn" type="button">−</button>' +
          '<input type="number" value="0" class="stepper-input" readonly>' +
          '<button class="occ-step-btn" type="button">+</button>' +
        '</div>' +
      '</div>' +
    '</div>';

  container.appendChild(card);

  // Wire up steppers on the new card
  card.querySelectorAll('.modal-stepper').forEach(stepper => {
    const btns = stepper.querySelectorAll('.occ-step-btn');
    const valEl = stepper.querySelector('.stepper-input');
    if (btns.length === 2 && valEl) {
      btns[0].addEventListener('click', () => {
        const v = parseInt(valEl.value);
        if (v > 0) valEl.value = v - 1;
      });
      btns[1].addEventListener('click', () => {
        const v = parseInt(valEl.value);
        if (v < 10) valEl.value = v + 1;
      });
    }
  });

  updateModifyRoomHeaders();
  updateModifyTotal();

  // Scroll the new card into view within the modal
  card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function removeModifyRoom(btn) {
  const card = btn.closest('.modal-room-card');
  card.classList.add('removing');
  card.addEventListener('animationend', () => {
    card.remove();
    renumberRooms();
    updateModifyRoomHeaders();
    updateModifyTotal();
  });
}

function renumberRooms() {
  const cards = document.querySelectorAll('#modify-rooms-container .modal-room-card');
  cards.forEach((card, i) => {
    const num = i + 1;
    card.dataset.roomIndex = num;
    const h4 = card.querySelector('.modal-room-card-header h4');
    if (h4) h4.textContent = 'Room ' + num;

    // Room 1 should never have a remove button; rooms 2+ should
    const existingRemove = card.querySelector('.btn-remove-room');
    if (num === 1 && existingRemove) {
      existingRemove.remove();
    }
  });
}

function updateBookingDetailFromState() {
  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);

  // Header price
  const headerPrice = document.getElementById('bd-header-price');
  if (headerPrice) headerPrice.textContent = 'USD ' + bookingState.price;

  // Service card rows
  const bdCheckin = document.getElementById('bd-checkin');
  const bdCheckout = document.getElementById('bd-checkout');
  const bdDuration = document.getElementById('bd-duration');
  const bdRoom = document.getElementById('bd-room');
  const bdMeal = document.getElementById('bd-meal');

  if (bdCheckin) bdCheckin.textContent = formatDate(bookingState.checkin);
  if (bdCheckout) bdCheckout.textContent = formatDate(bookingState.checkout);
  if (bdDuration) bdDuration.textContent = nights + ' Night' + (nights !== 1 ? 's' : '');
  if (bdRoom) bdRoom.textContent = bookingState.room;
  if (bdMeal) bdMeal.textContent = bookingState.mealPlan;
}

function updateBookingListFromState() {
  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);
  const ciShort = formatDateShort(bookingState.checkin);
  const coShort = formatDateShort(bookingState.checkout);

  // Update first booking card details
  const details = document.getElementById('blc1-details');
  if (details) {
    details.innerHTML =
      '<span>\uD83D\uDCC5 ' + ciShort + ' \u2013 ' + coShort + '</span>' +
      '<span>\u00B7 ' + nights + ' Night' + (nights !== 1 ? 's' : '') + '</span>' +
      '<span>\u00B7 2 Adults</span>' +
      '<span>\u00B7 ' + bookingState.mealPlan + '</span>';
  }

  // Update price
  const blcPrice = document.getElementById('blc1-price');
  if (blcPrice) blcPrice.textContent = 'USD ' + bookingState.price;
}

function addTimelineEntry(color, text) {
  const timeline = document.getElementById('bd-timeline');
  if (!timeline) return;
  const entry = document.createElement('div');
  entry.className = 'timeline-item';
  entry.innerHTML = '<span class="tl-dot ' + color + '"></span><span class="tl-text">' + text + '</span>';
  timeline.appendChild(entry);
}

// ========== CANCELLATION ==========

function showCancelSuccess() {
  bookingState.isCancelled = true;

  showToast('success', 'Booking Cancelled', 'Your booking has been cancelled. Refund of USD ' + bookingState.price + ' will be processed.');

  // Update status badges in booking detail
  const badges = document.querySelectorAll('#screen-booking-detail .status-badge.confirmed');
  badges.forEach(b => {
    b.textContent = 'CANCELLED';
    b.className = 'status-badge cancelled';
  });

  // Update cancellation banner
  const banner = document.querySelector('#screen-booking-detail .cancellation-banner');
  if (banner) {
    banner.className = 'cancellation-banner red';
    banner.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/></svg><span>This booking has been cancelled. Refund of USD ' + bookingState.price + ' is being processed.</span>';
  }

  // Update first booking card in My Bookings
  const blcStatus = document.getElementById('blc1-status');
  if (blcStatus) {
    blcStatus.textContent = 'CANCELLED';
    blcStatus.className = 'status-badge cancelled';
  }

  // Grey out the booking card
  const bookingCard = document.getElementById('booking-card-1');
  if (bookingCard) bookingCard.classList.add('cancelled-card');

  // Disable Modify/Cancel buttons
  const modifyBtn = document.getElementById('btn-modify-booking');
  const cancelBtn = document.getElementById('btn-cancel-booking');
  if (modifyBtn) modifyBtn.disabled = true;
  if (cancelBtn) cancelBtn.disabled = true;

  // Add "Cancelled" timeline entry
  addTimelineEntry('red', 'Cancelled: ' + nowFormatted());
}

// ========== BUTTON HANDLERS ==========

// "Book Again" buttons
document.querySelectorAll('.btn-rebook').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    showScreen('home');
    showToast('info', 'New Search', 'Start a new search to rebook this hotel.');
  });
});

// "Export CSV" button
document.querySelectorAll('.btn-outline').forEach(btn => {
  if (btn.textContent.includes('Export')) {
    btn.addEventListener('click', () => {
      showToast('success', 'Export Started', 'Your bookings CSV is being generated and will download shortly.');
    });
  }
});

// Voucher & Proforma downloads are handled by downloadVoucher() and downloadProforma() below

// Search bar edit button
document.querySelectorAll('.rsb-edit').forEach(btn => {
  btn.addEventListener('click', () => showScreen('home'));
});

// Gallery "+36 photos"
document.querySelectorAll('.gallery-more').forEach(el => {
  el.addEventListener('click', () => {
    showToast('info', 'Photo Gallery', 'Full photo gallery would open in a lightbox overlay.');
  });
});

// Sidebar links
document.querySelectorAll('.bookings-sidebar .sidebar-link').forEach(link => {
  if (!link.classList.contains('active')) {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      showToast('info', 'Navigation', `"${link.textContent.trim()}" page would open here.`);
    });
  }
});

// ========== DYNAMIC OCCUPANCY DROPDOWN ==========

const occRooms = [{ adults: 2, children: [10] }]; // Initial state: 1 room, 2 adults, 1 child age 10

function renderOccRooms() {
  const container = document.getElementById('occ-rooms-container');
  if (!container) return;
  container.innerHTML = '';

  occRooms.forEach((room, i) => {
    const div = document.createElement('div');
    div.className = 'occ-room';
    const childAgesHTML = room.children.map((age, ci) =>
      `<div class="occ-child-age-item">
        <label>Child ${ci + 1} age</label>
        <select onchange="occSetChildAge(${i},${ci},this.value)">
          ${Array.from({length: 18}, (_, a) => `<option value="${a}" ${a === age ? 'selected' : ''}>${a}</option>`).join('')}
        </select>
      </div>`
    ).join('');

    div.innerHTML =
      `<div class="occ-room-header">
        <span style="font-weight:700;font-size:15px">Room ${i + 1}</span>
        ${occRooms.length > 1 ? `<button class="occ-remove-room" onclick="occRemoveRoom(${i})"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg> Remove</button>` : ''}
      </div>
      <div class="occ-row">
        <div><div class="occ-label">Adults</div></div>
        <div class="occ-stepper">
          <button class="occ-step-btn" onclick="occStep(${i},'adults',-1)">−</button>
          <span>${room.adults}</span>
          <button class="occ-step-btn" onclick="occStep(${i},'adults',1)">+</button>
        </div>
      </div>
      <div class="occ-row">
        <div><div class="occ-label">Children</div><div class="occ-sublabel">Ages 0–17</div></div>
        <div class="occ-stepper">
          <button class="occ-step-btn" onclick="occStep(${i},'children',-1)">−</button>
          <span>${room.children.length}</span>
          <button class="occ-step-btn" onclick="occStep(${i},'children',1)">+</button>
        </div>
      </div>
      ${room.children.length > 0 ? `<div class="occ-child-ages">${childAgesHTML}</div>` : ''}`;

    container.appendChild(div);
  });

  updateOccSummary();
}

function occStep(roomIdx, type, delta) {
  const room = occRooms[roomIdx];
  if (type === 'adults') {
    room.adults = Math.max(1, Math.min(6, room.adults + delta));
  } else {
    const newCount = Math.max(0, Math.min(4, room.children.length + delta));
    if (delta > 0) room.children.push(10);
    else if (delta < 0 && room.children.length > 0) room.children.pop();
  }
  renderOccRooms();
}

function occSetChildAge(roomIdx, childIdx, age) {
  occRooms[roomIdx].children[childIdx] = parseInt(age);
}

function occRemoveRoom(idx) {
  if (occRooms.length <= 1) return;
  occRooms.splice(idx, 1);
  renderOccRooms();
}

function occAddRoom() {
  if (occRooms.length >= 5) {
    showToast('info', 'Room Limit', 'Maximum 5 rooms per booking.');
    return;
  }
  occRooms.push({ adults: 2, children: [] });
  renderOccRooms();
  // Scroll to new room
  const container = document.getElementById('occ-rooms-container');
  if (container) container.scrollTop = container.scrollHeight;
}

function updateOccSummary() {
  const totalRooms = occRooms.length;
  const totalAdults = occRooms.reduce((s, r) => s + r.adults, 0);
  const totalChildren = occRooms.reduce((s, r) => s + r.children.length, 0);
  let summary = totalRooms + ' Room' + (totalRooms > 1 ? 's' : '') + ', ' + totalAdults + ' Adult' + (totalAdults > 1 ? 's' : '');
  if (totalChildren > 0) summary += ', ' + totalChildren + ' Child' + (totalChildren > 1 ? 'ren' : '');
  const input = document.querySelector('.occupancy-trigger .search-input');
  if (input) input.value = summary;
}

function closeOccupancy() {
  document.getElementById('occupancy-dropdown').classList.remove('show');
}

// Wire up add room button
document.getElementById('occ-add-room-btn').addEventListener('click', (e) => {
  e.preventDefault();
  occAddRoom();
});

// Initial render
renderOccRooms();

// "Add Room" button in modify modal — real add/remove
document.getElementById('btn-add-room').addEventListener('click', addModifyRoom);

// "Apply" button in modify modal (date change)
document.querySelectorAll('.btn-apply').forEach(btn => {
  btn.addEventListener('click', () => {
    showToast('info', 'Dates Applied', 'Room availability would be recalculated for the new dates.');
  });
});

// Help button
document.querySelectorAll('.help-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    showToast('info', 'Help & Support', 'Live chat with our support team or call +1-800-ERGOS-24/7.');
  });
});

// Navbar icon buttons (globe, notification bell)
document.querySelectorAll('.navbar .icon-btn:not(.help-btn)').forEach(btn => {
  btn.addEventListener('click', () => {
    showToast('info', 'Feature', 'This feature would open in the full application.');
  });
});

// Avatar click
document.querySelectorAll('.avatar').forEach(el => {
  el.addEventListener('click', () => {
    showToast('info', 'Account', 'Account dropdown menu would appear here.');
  });
});

// "See full policy" link in booking detail
document.querySelectorAll('.cancellation-banner a').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    openModal('cancel-modal');
  });
});

// ========== TOAST NOTIFICATIONS ==========

function showToast(type, title, message) {
  const toast = document.getElementById('toast');
  const iconEl = document.getElementById('toast-icon');
  const titleEl = document.getElementById('toast-title');
  const messageEl = document.getElementById('toast-message');

  toast.className = 'toast show toast-' + type;

  if (type === 'success') {
    iconEl.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4 12 14.01l-3-3"/></svg>';
  } else if (type === 'error') {
    iconEl.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/></svg>';
  } else if (type === 'info') {
    iconEl.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>';
  }

  titleEl.textContent = title;
  messageEl.textContent = message;

  setTimeout(() => toast.classList.remove('show'), 4000);
}

// ========== CONFETTI ANIMATION ==========

function spawnConfetti() {
  const container = document.getElementById('conf-confetti');
  if (!container) return;
  container.innerHTML = '';
  const colors = ['#c4962c', '#4f46e5', '#0d9488', '#f59e0b', '#22c55e', '#ef4444', '#8b5cf6'];
  for (let i = 0; i < 60; i++) {
    const piece = document.createElement('div');
    piece.style.cssText =
      'position:absolute;width:' + (6 + Math.random() * 6) + 'px;height:' + (6 + Math.random() * 6) + 'px;' +
      'background:' + colors[Math.floor(Math.random() * colors.length)] + ';' +
      'left:' + Math.random() * 100 + '%;top:-20px;' +
      'border-radius:' + (Math.random() > .5 ? '50%' : '2px') + ';' +
      'animation:confettiFall ' + (1.5 + Math.random() * 2) + 's ease-out forwards;' +
      'animation-delay:' + (Math.random() * .5) + 's;' +
      'opacity:.9;transform:rotate(' + Math.random() * 360 + 'deg);';
    container.appendChild(piece);
  }
  // Clean up after animation
  setTimeout(() => { container.innerHTML = ''; }, 4500);
}

// ========== SEARCH RESULTS FILTERS & SORTING ==========

(function initFilters() {
  const nameInput = document.getElementById('filter-hotel-name');
  const priceRange = document.getElementById('filter-price-range');
  const priceLabel = document.getElementById('filter-price-label');
  const sortSelect = document.getElementById('filter-sort');
  const resultsCount = document.getElementById('results-count');
  const resultsList = document.getElementById('results-list');

  if (!resultsList) return;

  function getHotelCards() {
    return Array.from(resultsList.querySelectorAll('.hotel-card'));
  }

  function getCheckedValues(selector, attr) {
    const checked = document.querySelectorAll(selector + ':checked');
    if (checked.length === 0) return null; // none checked = no filter
    return Array.from(checked).map(cb => cb.getAttribute(attr));
  }

  function applyFilters() {
    const cards = getHotelCards();
    const nameQuery = nameInput.value.trim().toLowerCase();
    const maxPrice = parseInt(priceRange.value);
    const starFilters = getCheckedValues('.filter-star', 'data-stars');
    const mealFilters = getCheckedValues('.filter-meal', 'data-meal');
    const refundValue = document.querySelector('.filter-refund:checked')?.value || 'all';

    // Update price label
    priceLabel.textContent = maxPrice >= 2000 ? '$2,000+' : '$' + maxPrice.toLocaleString();

    let visibleCount = 0;

    cards.forEach(card => {
      const cardName = (card.dataset.name || '').toLowerCase();
      const cardPrice = parseFloat(card.dataset.price) || 0;
      const cardStars = card.dataset.stars;
      const cardMeal = card.dataset.meal;
      const cardRefund = card.dataset.refund;

      let visible = true;

      // Hotel name filter
      if (nameQuery && !cardName.includes(nameQuery)) visible = false;

      // Price range filter
      if (maxPrice < 2000 && cardPrice > maxPrice) visible = false;

      // Star category filter (if any checked)
      if (starFilters && !starFilters.includes(cardStars)) visible = false;

      // Meal plan filter (if any checked)
      if (mealFilters && !mealFilters.includes(cardMeal)) visible = false;

      // Cancellation policy filter
      if (refundValue === 'refundable' && cardRefund !== 'refundable') visible = false;
      if (refundValue === 'nonrefundable' && cardRefund !== 'nonrefundable') visible = false;

      card.style.display = visible ? '' : 'none';
      if (visible) visibleCount++;
    });

    // Update results count
    resultsCount.textContent = visibleCount + ' hotel' + (visibleCount !== 1 ? 's' : '') + ' found in Havana, Cuba';
  }

  function applySort() {
    const cards = getHotelCards();
    const sortVal = sortSelect.value;
    const header = resultsList.querySelector('.results-header');

    cards.sort((a, b) => {
      switch (sortVal) {
        case 'price-asc':
          return (parseFloat(a.dataset.price) || 0) - (parseFloat(b.dataset.price) || 0);
        case 'price-desc':
          return (parseFloat(b.dataset.price) || 0) - (parseFloat(a.dataset.price) || 0);
        case 'stars':
          return (parseInt(b.dataset.stars) || 0) - (parseInt(a.dataset.stars) || 0);
        case 'name':
          return (a.dataset.name || '').localeCompare(b.dataset.name || '');
        default:
          return 0;
      }
    });

    // Re-append cards in sorted order (header stays first)
    cards.forEach(card => resultsList.appendChild(card));
  }

  // Wire up event listeners
  nameInput.addEventListener('input', applyFilters);
  priceRange.addEventListener('input', applyFilters);
  sortSelect.addEventListener('change', () => { applySort(); applyFilters(); });

  document.querySelectorAll('.filter-star, .filter-meal, .filter-refund').forEach(el => {
    el.addEventListener('change', applyFilters);
  });
})();

// ========== VOUCHER & PROFORMA DOWNLOAD ==========

function buildVoucherHTML(lang) {
  const isES = lang === 'Spanish';
  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);
  const ref = bookingState.bookingRef || 'PTA18G28E7CUANQ';
  const guestName = bookingState.guestFirstName + ' ' + bookingState.guestLastName;

  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'Segoe UI',Arial,sans-serif; color:#292524; padding:40px; max-width:800px; margin:0 auto; }
  .header { display:flex; justify-content:space-between; align-items:center; border-bottom:3px solid #1a1a4e; padding-bottom:20px; margin-bottom:30px; }
  .brand { font-size:24px; font-weight:700; color:#1a1a4e; }
  .brand-sub { font-size:12px; color:#78716c; }
  .doc-title { font-size:28px; font-weight:700; color:#1a1a4e; text-align:right; }
  .doc-subtitle { font-size:12px; color:#78716c; text-align:right; }
  .ref-bar { background:#1a1a4e; color:#fff; padding:14px 20px; border-radius:6px; display:flex; justify-content:space-between; margin-bottom:24px; font-size:14px; }
  .ref-bar strong { font-size:16px; }
  .section { margin-bottom:24px; }
  .section h3 { font-size:11px; font-weight:700; color:#78716c; text-transform:uppercase; letter-spacing:1px; margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid #e8e5e0; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 32px; }
  .field-label { font-size:11px; color:#a8a093; font-weight:600; text-transform:uppercase; letter-spacing:.5px; }
  .field-value { font-size:14px; font-weight:600; margin-bottom:8px; }
  .total-bar { background:#f5f3f0; padding:16px 20px; border-radius:6px; display:flex; justify-content:space-between; align-items:center; margin:24px 0; font-size:16px; font-weight:700; }
  .total-amount { font-size:24px; color:#0d9488; }
  .policy { padding:12px 16px; border-radius:6px; font-size:13px; margin-bottom:20px; }
  .policy.green { background:#ccfbf1; color:#115e59; border:1px solid #99f6e4; }
  .footer { border-top:2px solid #e8e5e0; padding-top:20px; margin-top:30px; font-size:11px; color:#a8a093; text-align:center; line-height:1.8; }
  .footer strong { color:#78716c; }
  @media print { body { padding:20px; } }
</style></head><body>
<div class="header">
  <div><div class="brand">Ergos Continental</div><div class="brand-sub">${isES ? 'Plataforma de Reservas de Viajes' : 'Travel Booking Platform'}</div></div>
  <div><div class="doc-title">${isES ? 'BONO DE RESERVA' : 'BOOKING VOUCHER'}</div><div class="doc-subtitle">${isES ? 'Documento oficial de confirmación' : 'Official Confirmation Document'}</div></div>
</div>
<div class="ref-bar">
  <div>${isES ? 'Referencia de reserva' : 'Booking Reference'}: <strong>${ref}</strong></div>
  <div>${isES ? 'Estado' : 'Status'}: ${bookingState.isCancelled ? (isES ? 'CANCELADA' : 'CANCELLED') : (isES ? 'CONFIRMADA' : 'CONFIRMED')}</div>
</div>
<div class="section"><h3>${isES ? 'Detalles del Hotel' : 'Hotel Details'}</h3>
<div class="grid">
  <div><div class="field-label">${isES ? 'Hotel' : 'Hotel'}</div><div class="field-value">${bookingState.hotel} ${bookingState.hotelStars}</div></div>
  <div><div class="field-label">${isES ? 'Dirección' : 'Address'}</div><div class="field-value">Calle 66, Miramar, Playa, Havana</div></div>
  <div><div class="field-label">${isES ? 'Entrada' : 'Check-in'}</div><div class="field-value">${formatDate(bookingState.checkin)}</div></div>
  <div><div class="field-label">${isES ? 'Salida' : 'Check-out'}</div><div class="field-value">${formatDate(bookingState.checkout)}</div></div>
  <div><div class="field-label">${isES ? 'Duración' : 'Duration'}</div><div class="field-value">${nights} ${isES ? 'Noche' : 'Night'}${nights !== 1 ? 's' : ''}</div></div>
  <div><div class="field-label">${isES ? 'Habitación' : 'Room'}</div><div class="field-value">${bookingState.room}</div></div>
  <div><div class="field-label">${isES ? 'Régimen' : 'Meal Plan'}</div><div class="field-value">${bookingState.mealPlan}</div></div>
  <div><div class="field-label">${isES ? 'Ocupación' : 'Occupancy'}</div><div class="field-value">2 ${isES ? 'Adultos' : 'Adults'}</div></div>
</div></div>
<div class="section"><h3>${isES ? 'Información del Huésped' : 'Guest Information'}</h3>
<div class="grid">
  <div><div class="field-label">${isES ? 'Nombre' : 'Guest Name'}</div><div class="field-value">${guestName}</div></div>
  <div><div class="field-label">${isES ? 'Correo' : 'Email'}</div><div class="field-value">${bookingState.guestEmail}</div></div>
</div></div>
<div class="policy green">${isES ? 'Cancelación gratuita hasta el' : 'Free cancellation until'} ${formatDate(bookingState.checkin)}</div>
<div class="total-bar"><span>${isES ? 'Precio Total del Cliente' : 'Total Client Price'}</span><span class="total-amount">USD ${bookingState.price}</span></div>
<div class="footer">
  <strong>Ergos Continental</strong> — ${isES ? 'Este bono es su confirmación oficial. Preséntelo al hacer el check-in.' : 'This voucher is your official confirmation. Please present it at check-in.'}<br>
  ${isES ? 'Generado el' : 'Generated on'} ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}<br>
  ${isES ? 'Para soporte: support@ergoscontinental.com | +1-800-ERGOS' : 'For support: support@ergoscontinental.com | +1-800-ERGOS'}
</div>
</body></html>`;
}

function buildProformaHTML(lang) {
  const isES = lang === 'Spanish';
  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);
  const ref = bookingState.bookingRef || 'PTA18G28E7CUANQ';
  const guestName = bookingState.guestFirstName + ' ' + bookingState.guestLastName;
  const perNight = (parseFloat(bookingState.price) / nights).toFixed(2);

  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family:'Segoe UI',Arial,sans-serif; color:#292524; padding:40px; max-width:800px; margin:0 auto; }
  .header { display:flex; justify-content:space-between; align-items:center; border-bottom:3px solid #1a1a4e; padding-bottom:20px; margin-bottom:30px; }
  .brand { font-size:24px; font-weight:700; color:#1a1a4e; }
  .brand-sub { font-size:12px; color:#78716c; }
  .doc-title { font-size:28px; font-weight:700; color:#1a1a4e; text-align:right; }
  .doc-subtitle { font-size:12px; color:#78716c; text-align:right; }
  .ref-bar { background:#1a1a4e; color:#fff; padding:14px 20px; border-radius:6px; display:flex; justify-content:space-between; margin-bottom:24px; font-size:14px; }
  .ref-bar strong { font-size:16px; }
  .section { margin-bottom:24px; }
  .section h3 { font-size:11px; font-weight:700; color:#78716c; text-transform:uppercase; letter-spacing:1px; margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid #e8e5e0; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px 32px; }
  .field-label { font-size:11px; color:#a8a093; font-weight:600; text-transform:uppercase; letter-spacing:.5px; }
  .field-value { font-size:14px; font-weight:600; margin-bottom:8px; }
  table { width:100%; border-collapse:collapse; margin:16px 0; font-size:14px; }
  th { background:#f5f3f0; text-align:left; padding:10px 14px; font-size:11px; font-weight:700; color:#78716c; text-transform:uppercase; letter-spacing:.5px; border-bottom:1px solid #e8e5e0; }
  td { padding:10px 14px; border-bottom:1px solid #e8e5e0; }
  td.right { text-align:right; font-weight:600; }
  .total-row td { font-weight:700; font-size:16px; border-top:2px solid #292524; border-bottom:none; }
  .footer { border-top:2px solid #e8e5e0; padding-top:20px; margin-top:30px; font-size:11px; color:#a8a093; text-align:center; line-height:1.8; }
  .footer strong { color:#78716c; }
  @media print { body { padding:20px; } }
</style></head><body>
<div class="header">
  <div><div class="brand">Ergos Continental</div><div class="brand-sub">${isES ? 'Plataforma de Reservas de Viajes' : 'Travel Booking Platform'}</div></div>
  <div><div class="doc-title">${isES ? 'FACTURA PROFORMA' : 'PROFORMA INVOICE'}</div><div class="doc-subtitle">${isES ? 'Ref' : 'Ref'}: ${ref}</div></div>
</div>
<div class="ref-bar">
  <div>${isES ? 'Fecha' : 'Date'}: <strong>${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</strong></div>
  <div>${isES ? 'Estado de pago' : 'Payment Status'}: ${isES ? 'PAGADO' : 'PAID'}</div>
</div>
<div class="section"><h3>${isES ? 'Facturar a' : 'Bill To'}</h3>
<div class="grid">
  <div><div class="field-label">${isES ? 'Nombre' : 'Name'}</div><div class="field-value">${guestName}</div></div>
  <div><div class="field-label">${isES ? 'Correo' : 'Email'}</div><div class="field-value">${bookingState.guestEmail}</div></div>
</div></div>
<div class="section"><h3>${isES ? 'Detalles del Servicio' : 'Service Details'}</h3>
<table>
  <thead><tr><th>${isES ? 'Descripción' : 'Description'}</th><th>${isES ? 'Cant.' : 'Qty'}</th><th style="text-align:right">${isES ? 'Precio Unit.' : 'Unit Price'}</th><th style="text-align:right">${isES ? 'Total' : 'Total'}</th></tr></thead>
  <tbody>
    <tr><td>${bookingState.hotel} — ${bookingState.room}<br><span style="font-size:12px;color:#78716c">${bookingState.mealPlan} · ${formatDate(bookingState.checkin)} → ${formatDate(bookingState.checkout)}</span></td><td>${nights} ${isES ? 'noche' : 'night'}${nights !== 1 ? 's' : ''}</td><td class="right">USD ${perNight}</td><td class="right">USD ${bookingState.price}</td></tr>
    <tr class="total-row"><td colspan="3">${isES ? 'TOTAL A PAGAR' : 'TOTAL DUE'}</td><td class="right" style="color:#0d9488">USD ${bookingState.price}</td></tr>
  </tbody>
</table></div>
<div class="section"><h3>${isES ? 'Información de Pago' : 'Payment Information'}</h3>
<div class="grid">
  <div><div class="field-label">${isES ? 'Método' : 'Method'}</div><div class="field-value">${isES ? 'Tarjeta de Crédito' : 'Credit Card'} (Visa ****4222)</div></div>
  <div><div class="field-label">${isES ? 'Estado' : 'Status'}</div><div class="field-value" style="color:#0d9488">${isES ? 'PAGADO EN SU TOTALIDAD' : 'PAID IN FULL'}</div></div>
</div></div>
<div class="footer">
  <strong>Ergos Continental</strong> — ${isES ? 'Esta es una factura proforma y no constituye una factura fiscal.' : 'This is a proforma invoice and does not constitute a tax invoice.'}<br>
  ${isES ? 'Generado el' : 'Generated on'} ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
</div>
</body></html>`;
}

function triggerHTMLDownload(html, filename) {
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function downloadVoucher() {
  const lang = document.getElementById('voucher-lang')?.value || document.getElementById('voucher-preview-lang')?.value || 'English';
  const ref = bookingState.bookingRef || 'PTA18G28E7CUANQ';
  const html = buildVoucherHTML(lang);
  triggerHTMLDownload(html, 'Voucher_' + ref + '.html');
  showToast('success', 'Voucher Downloaded', 'Booking voucher has been saved. Open it in a browser and print to PDF.');
}

function downloadProforma() {
  const lang = document.getElementById('invoice-lang')?.value || document.getElementById('invoice-preview-lang')?.value || 'English';
  const ref = bookingState.bookingRef || 'PTA18G28E7CUANQ';
  const html = buildProformaHTML(lang);
  triggerHTMLDownload(html, 'Proforma_' + ref + '.html');
  showToast('success', 'Invoice Downloaded', 'Proforma invoice has been saved. Open it in a browser and print to PDF.');
}

// ========== INLINE DOCUMENT PREVIEW ==========

function buildVoucherPreview(lang) {
  const isES = lang === 'Spanish';
  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);
  const ref = bookingState.bookingRef || 'PTA18G28E7CUANQ';
  const guestName = bookingState.guestFirstName + ' ' + bookingState.guestLastName;
  const statusClass = bookingState.isCancelled ? 'cancelled' : 'confirmed';
  const statusText = bookingState.isCancelled ? (isES ? 'CANCELADA' : 'CANCELLED') : (isES ? 'CONFIRMADA' : 'CONFIRMED');

  return `
    ${bookingState.isCancelled ? '<div class="doc-watermark">CANCELLED</div>' : ''}
    <div class="doc-header">
      <div>
        <div class="doc-brand">Ergos Continental</div>
        <div class="doc-brand-sub">${isES ? 'Plataforma de Reservas de Viajes' : 'Travel Booking Platform'}</div>
      </div>
      <div>
        <div class="doc-title">${isES ? 'BONO DE RESERVA' : 'BOOKING VOUCHER'}</div>
        <div class="doc-subtitle">${isES ? 'Documento oficial de confirmación' : 'Official Confirmation Document'}</div>
      </div>
    </div>
    <div class="doc-ref-bar">
      <div>${isES ? 'Referencia de reserva' : 'Booking Reference'}: <strong>${ref}</strong></div>
      <div><span class="doc-status ${statusClass}">${statusText}</span></div>
    </div>
    <div class="doc-section">
      <div class="doc-section-title">${isES ? 'Detalles del Hotel' : 'Hotel Details'}</div>
      <div class="doc-grid">
        <div><div class="doc-field-label">${isES ? 'Hotel' : 'Hotel'}</div><div class="doc-field-value">${bookingState.hotel} ${bookingState.hotelStars}</div></div>
        <div><div class="doc-field-label">${isES ? 'Dirección' : 'Address'}</div><div class="doc-field-value">Calle 66, Miramar, Playa, Havana</div></div>
        <div><div class="doc-field-label">${isES ? 'Entrada' : 'Check-in'}</div><div class="doc-field-value">${formatDate(bookingState.checkin)}</div></div>
        <div><div class="doc-field-label">${isES ? 'Salida' : 'Check-out'}</div><div class="doc-field-value">${formatDate(bookingState.checkout)}</div></div>
        <div><div class="doc-field-label">${isES ? 'Duración' : 'Duration'}</div><div class="doc-field-value">${nights} ${isES ? 'Noche' : 'Night'}${nights !== 1 ? 's' : ''}</div></div>
        <div><div class="doc-field-label">${isES ? 'Habitación' : 'Room'}</div><div class="doc-field-value">${bookingState.room}</div></div>
        <div><div class="doc-field-label">${isES ? 'Régimen' : 'Meal Plan'}</div><div class="doc-field-value">${bookingState.mealPlan}</div></div>
        <div><div class="doc-field-label">${isES ? 'Ocupación' : 'Occupancy'}</div><div class="doc-field-value">2 ${isES ? 'Adultos' : 'Adults'}</div></div>
      </div>
    </div>
    <div class="doc-section">
      <div class="doc-section-title">${isES ? 'Información del Huésped' : 'Guest Information'}</div>
      <div class="doc-grid">
        <div><div class="doc-field-label">${isES ? 'Nombre' : 'Guest Name'}</div><div class="doc-field-value">${guestName}</div></div>
        <div><div class="doc-field-label">${isES ? 'Correo' : 'Email'}</div><div class="doc-field-value">${bookingState.guestEmail}</div></div>
      </div>
    </div>
    <div class="doc-policy">${isES ? 'Cancelación gratuita hasta el' : 'Free cancellation until'} ${formatDate(bookingState.checkin)}</div>
    <div class="doc-total-bar">
      <span>${isES ? 'Precio Total del Cliente' : 'Total Client Price'}</span>
      <span class="doc-total-amount">USD ${bookingState.price}</span>
    </div>
    <div class="doc-footer">
      <strong>Ergos Continental</strong> — ${isES ? 'Este bono es su confirmación oficial. Preséntelo al hacer el check-in.' : 'This voucher is your official confirmation. Please present it at check-in.'}<br>
      ${isES ? 'Generado el' : 'Generated on'} ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}<br>
      ${isES ? 'Para soporte' : 'For support'}: support@ergoscontinental.com | +1-800-ERGOS
    </div>`;
}

function buildInvoicePreview(lang) {
  const isES = lang === 'Spanish';
  const nights = nightsBetween(bookingState.checkin, bookingState.checkout);
  const ref = bookingState.bookingRef || 'PTA18G28E7CUANQ';
  const guestName = bookingState.guestFirstName + ' ' + bookingState.guestLastName;
  const perNight = (parseFloat(bookingState.price) / nights).toFixed(2);

  return `
    <div class="doc-header">
      <div>
        <div class="doc-brand">Ergos Continental</div>
        <div class="doc-brand-sub">${isES ? 'Plataforma de Reservas de Viajes' : 'Travel Booking Platform'}</div>
      </div>
      <div>
        <div class="doc-title">${isES ? 'FACTURA PROFORMA' : 'PROFORMA INVOICE'}</div>
        <div class="doc-subtitle">${isES ? 'Ref' : 'Ref'}: ${ref}</div>
      </div>
    </div>
    <div class="doc-ref-bar">
      <div>${isES ? 'Fecha' : 'Date'}: <strong>${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</strong></div>
      <div><span class="doc-status paid">${isES ? 'PAGADO' : 'PAID'}</span></div>
    </div>
    <div class="doc-section">
      <div class="doc-section-title">${isES ? 'Facturar a' : 'Bill To'}</div>
      <div class="doc-grid">
        <div><div class="doc-field-label">${isES ? 'Nombre' : 'Name'}</div><div class="doc-field-value">${guestName}</div></div>
        <div><div class="doc-field-label">${isES ? 'Correo' : 'Email'}</div><div class="doc-field-value">${bookingState.guestEmail}</div></div>
      </div>
    </div>
    <div class="doc-section">
      <div class="doc-section-title">${isES ? 'Detalles del Servicio' : 'Service Details'}</div>
      <table class="doc-table">
        <thead>
          <tr>
            <th>${isES ? 'Descripción' : 'Description'}</th>
            <th>${isES ? 'Cant.' : 'Qty'}</th>
            <th style="text-align:right">${isES ? 'Precio Unit.' : 'Unit Price'}</th>
            <th style="text-align:right">${isES ? 'Total' : 'Total'}</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              ${bookingState.hotel} — ${bookingState.room}
              <div class="doc-desc-sub">${bookingState.mealPlan} · ${formatDate(bookingState.checkin)} → ${formatDate(bookingState.checkout)}</div>
            </td>
            <td>${nights} ${isES ? 'noche' : 'night'}${nights !== 1 ? 's' : ''}</td>
            <td class="right">USD ${perNight}</td>
            <td class="right">USD ${bookingState.price}</td>
          </tr>
          <tr class="total-row">
            <td colspan="3">${isES ? 'TOTAL A PAGAR' : 'TOTAL DUE'}</td>
            <td class="right" style="color:var(--teal)">USD ${bookingState.price}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="doc-section">
      <div class="doc-section-title">${isES ? 'Información de Pago' : 'Payment Information'}</div>
      <div class="doc-grid">
        <div><div class="doc-field-label">${isES ? 'Método' : 'Method'}</div><div class="doc-field-value">${isES ? 'Tarjeta de Crédito' : 'Credit Card'} (Visa ****4222)</div></div>
        <div><div class="doc-field-label">${isES ? 'Estado' : 'Status'}</div><div class="doc-field-value" style="color:var(--teal)">${isES ? 'PAGADO EN SU TOTALIDAD' : 'PAID IN FULL'}</div></div>
      </div>
    </div>
    <div class="doc-footer">
      <strong>Ergos Continental</strong> — ${isES ? 'Esta es una factura proforma y no constituye una factura fiscal.' : 'This is a proforma invoice and does not constitute a tax invoice.'}<br>
      ${isES ? 'Generado el' : 'Generated on'} ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
    </div>`;
}

function renderVoucherPreview() {
  const lang = document.getElementById('voucher-preview-lang')?.value || 'English';
  document.getElementById('voucher-preview-content').innerHTML = buildVoucherPreview(lang);
}

function renderInvoicePreview() {
  const lang = document.getElementById('invoice-preview-lang')?.value || 'English';
  document.getElementById('invoice-preview-content').innerHTML = buildInvoicePreview(lang);
}

function openVoucherPreview() {
  const lang = document.getElementById('voucher-lang')?.value || 'English';
  const langSelect = document.getElementById('voucher-preview-lang');
  if (langSelect) langSelect.value = lang;
  renderVoucherPreview();
  showScreen('voucher');
}

function openInvoicePreview() {
  const lang = document.getElementById('invoice-lang')?.value || 'English';
  const langSelect = document.getElementById('invoice-preview-lang');
  if (langSelect) langSelect.value = lang;
  renderInvoicePreview();
  showScreen('invoice');
}

function printDocPreview(type) {
  window.print();
}
